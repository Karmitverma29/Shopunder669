import Navbar from "../Nav.js";

let nav=document.getElementById("nav");
nav.innerHTML=Navbar();