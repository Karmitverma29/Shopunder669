
function Navbar(){
    return `
    <div class="top">
    <div class="search-container">
    <form>
      <input type="text" placeholder="Search..." id="search-input">
      <button type="submit" id="search-btn">Search</button>
    </form>
  </div>
    <div class=cred>
<button>Login</button>
<button>Signup</button>
 


     </div>
    
</div>
    <div class="header">
       
    <a href="./index.html">  <h1 class="logoname">SHOPUNDER669</h1> </a>
 </div>
 
     
 </div>
 
 `
}

export default Navbar;


